const { Client, GatewayIntentBits } = require("discord.js");
const client = new Client({ intents: [GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent] });

client.on('messageCreate',(message) =>{
    if (message.author.bot) return;
    if(message.content.startsWith('create')){
        const url = message.content.split('create')[1]
        return message.reply({
            content: "Generating the short ID for" +url,
        });
    }
    message.reply({
        content: "Hi from the bot",
    })
});

client.on("interactionCreate",(interaction) => {
    console.log(interaction);
    interaction.reply('Pong');
})
client.login('MTI0NTQzNzQ4NTQyNTg4NTI2NQ.GSiRlR.H6k1AtSx5arL9WLAH2exoRR_pF_YG3rwy80NTU');
