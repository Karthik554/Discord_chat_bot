const { REST, Routes } = require('discord.js');
const commands = [
  {
    name: 'create',
    description: 'Creates a new short url',
  },
];

const rest = new REST({ version: '10' }).setToken('MTI0NTQzNzQ4NTQyNTg4NTI2NQ.GSiRlR.H6k1AtSx5arL9WLAH2exoRR_pF_YG3rwy80NTU');

(async () => {
  try {
    console.log('Started refreshing application (/) commands.');

    await rest.put(Routes.applicationCommands('1245437485425885265'), { body: commands });

    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error(error);
  }
})();